#gixtuh's yet 2nd hyprland rice

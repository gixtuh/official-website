clear
echo "gixtuh's hyprland dotfiles remade"
echo "this setup requires an aur installer like yay and paru"
echo ""
echo "do you want to install the dotfiles (yes/no)"
read ok
if [[ "$ok" == "no" ]]; then
    exit
fi
clear
echo "in order for wallpaper switching to work properly, sudo needs to NOT ask for passwords for users in group wheel, wanna modify sudo to stop asking for the password? (yes/no)"
read sudonopasswd
clear
echo "this is required because this rice does NOT support zsh"
echo "do you want to change your shell to bash before the copying starts? (yes/no)"
read bash
clear
echo "do you use yay or paru? (yay/paru, ctrl+c if NONE)"
read aur
clear
echo "add pywal support for discord? (yes/no)"
read discord-pywal
clear
echo "add GTK app support? (yes/no)"
read gtkapp
clear
echo "if you enter no then you'll have to specify the keybinds for your browser in the hyprland.conf file"
echo "in order for the super+b and super+shift+x keybinds to work you'll need torbrowser-launcher and zen-browser, install them? (yes/no)"
read torfirefox
clear
echo "last thing uhh do you want to sign out of hyprland after installation so that the changes wouldve been applied (yes/no)"
read restarthypr
clear
if [[ "$bash" == "yes" ]]; then
	sudo chsh -s /usr/bin/bash
fi
if [[ "$sudonopasswd" == "yes" ]]; then
	sudo mkdir /etc/sudoers.d
	cat <<EOF2 | sudo tee /etc/sudoers.d/myOverrides
%wheel ALL=(ALL:ALL) NOPASSWD: ALL
EOF2
fi
rm -rf ~/.config/hypr/*
cp -rv config/hypr/* ~/.config/hypr
hyprctl reload
rm -rf ~/.bashrc
cp -r config/bashrc ~/.bashrc
rm -rf ~/.config/rofi
mkdir ~/.config/rofi
cp -rv config/rofi/* ~/.config/rofi/
rm -rf ~/.config/waybar
mkdir ~/.config/waybar
cp -rv config/waybar/* ~/.config/waybar/
rm -rf ~/.config/cava
mkdir ~/.config/cava
cp -rv config/cava/* ~/.config/cava/
rm -rf ~/.config/swaync
mkdir ~/.config/swaync
cp -rv config/swaync/* ~/.config/swaync/
sudo cp -rv config/wlogout/* /etc/wlogout/
rm -rf ~/.config/hypremoji
mkdir ~/.config/hypremoji
cp -rv config/hypremoji/* ~/.config/hypremoji
rm -rf ~/.config/fastfetch
mkdir ~/.config/fastfetch
cp -rv config/fastfetch/* ~/.config/fastfetch
sudo rm -rf /usr/share/HyprlandRoot/
sudo mkdir /usr/share/HyprlandRoot
sudo cp -rv config/hyprroot/* /usr/share/HyprlandRoot/
sudo rm -rf /etc/wlogout
rm -rf ~/.config/alacritty
mkdir ~/.config/alacritty
cp -rv config/alacritty/* ~/.config/alacritty
clear
if [[ "$aur" == "yay" ]]; then
    yay -Sy --nodeps --noconfirm alacritty swww cava waybar rofi swaync hyprpolkitagent inotify-tools wlogout neovide hypremoji swaylock-effects fastfetch python-pywal16-git thunar otf-font-awesome nerd-fonts yad hyprutils-git hyprwayland-scanner-git aquamarine-git hyprgraphics-git hyprlang-git hyprtoolkit-git hyprshutdown-git blesh
	yay -Rns --nodeps hyprutils hyprwayland-scanner-git aquamarine hyprgraphics hyprlang hyprtoolkit
	if [[ "$discord-pywal" == "yes" ]]; then
		yay -Sy --noconfirm pywal-discord
	fi
	if [[ "$gtkapp" == "yes" ]]; then
		yay -Sy --noconfirm wpgtk
	fi
	if [[ "$torfirefox" == "yes" ]]; then
		yay -Sy --noconfirm torbrowser-launcher zen-browser
	fi
else
    paru -Sy --nodeps --noconfirm alacritty swww cava waybar rofi swaync hyprpolkitagent inotify-tools wlogout neovide hypremoji swaylock-effects fastfetch python-pywal16-git thunar otf-font-awesome nerd-fonts yad hyprutils-git hyprwayland-scanner-git aquamarine-git hyprgraphics-git hyprlang-git hyprtoolkit-git hyprshutdown-git blesh
	paru -Rns --nodeps hyprutils hyprwayland-scanner-git aquamarine hyprgraphics hyprlang hyprtoolkit
	if [[ "$discord-pywal" == "yes" ]]; then
		paru -Sy --noconfirm pywal-discord
	fi
	if [[ "$gtkapp" == "yes" ]]; then
		paru -Sy --noconfirm wpgtk
	fi
	if [[ "$torfirefox" == "yes" ]]; then
		paru -Sy --noconfirm torbrowser-launcher zen-browser
	fi
fi
clear
echo "DEBUG: some commands will say "command not found" because you specified NOT to install them... or maybe not because you already have them installed"
echo ""
sleep 1
wpg-install.sh -g
pywal-discord -d
gsettings set org.gnome.desktop.interface gtk-theme "FlatColor"
sleep 1
sudo mkdir /etc/wlogout
sudo cp -rv config/wlogout/* /etc/wlogout/
echo "done done"
if [[ "$restarthypr" == "yes" ]]; then
	sudo killall Hyprland
else
	hyprctl reload
fi

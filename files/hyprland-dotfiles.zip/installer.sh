clear
echo "do you want to install the dotfiles"
echo ""
echo "set your default shell to bash before installing these dotfiles"
echo ""
echo "answer with either yes or no"
read ok
if [[ "$ok" == "no" ]]; then
    exit
fi
clear
hheh=yes
if ! [[ "$hheh" == "yes" ]]; then
clear
echo ok. i will now install things ok..?
sleep 2
clear
echo good.
sleep 1
clear
echo holdup lemme install some hyprland configs ok?
sleep 2
fi
rm -rf ~/.config/hypr/*
cp -rv config/hypr/* ~/.config/hypr
if ! [[ "$hheh" == "yes" ]]; then
clear
echo whoops wait the hyprland config aint right lemme fix that
sleep 3
fi
hyprctl reload
if ! [[ "$hheh" == "yes" ]]; then
clear
echo ah yes here we go
sleep 3
clear
echo time for...
clear
sleep 2
clear
echo BASHRC REPLACEMENT!
clear
sleep 2
clear
echo just make sure you use bashrc lol
clear
sleep 2
clear
echo okay... 1... 2... 3...
sleep 2
fi
rm -rf ~/.bashrc
cp -r config/bashrc ~/.bashrc
if ! [[ "$hheh" == "yes" ]]; then
clear
echo BOOM!
sleep 1
clear
echo "ok now we replace a bunch more config files youll need to wait (ithink)"
sleep 2
clear
echo "AND DONT WORRY ABOUT THE BUNCH OF LOGS THATS JUST WHAT WAS COPIED"
sleep 2
fi
rm -rf ~/.config/rofi
mkdir ~/.config/rofi
cp -rv config/rofi/* ~/.config/rofi/
rm -rf ~/.config/waybar
mkdir ~/.config/waybar
cp -rv config/waybar/* ~/.config/waybar/
rm -rf ~/.config/cava
mkdir ~/.config/cava
cp -rv config/cava/* ~/.config/cava/
rm -rf ~/.config/swaync
mkdir ~/.config/swaync
cp -rv config/swaync/* ~/.config/swaync/
sudo cp -rv config/wlogout/* /etc/wlogout/
rm -rf ~/.config/hypremoji
mkdir ~/.config/hypremoji
cp -rv config/hypremoji/* ~/.config/hypremoji
rm -rf ~/.config/fastfetch
mkdir ~/.config/fastfetch
cp -rv config/fastfetch/* ~/.config/fastfetch
if ! [[ "$hheh" == "yes" ]]; then
clear
echo "dont forget about hyprlandroot"
fi
sudo rm -rf /usr/share/HyprlandRoot/
sudo mkdir /usr/share/HyprlandRoot
sudo cp -rv config/hyprroot/* /usr/share/HyprlandRoot/
if ! [[ "$hheh" == "yes" ]]; then
clear
echo "ok now it's time for dependencies"
sleep 2
clear
echo "i'll install alacritty, swww, cava, waybar, rofi, firefox, swaync, torbrowser-launcher, hyprpolkitagent, inotify-tools, neovide, hypremoji, swaylock fastfetch, python-pywal, thunar, otf-font-awesome nerd-fonts and wlogout"
sleep 2
clear
echo "isn't that a LOT of dependencies?.. yeah.. it iS."
sleep 2
fi
clear
echo "do you use yay or paru? (ctrl+c if NONE, answer with either yay or paru)"
read ok
if [[ "$ok" == "yay" ]]; then
    yay -Sy --noconfirm alacritty swww cava waybar rofi firefox swaync torbrowser-launcher hyprpolkitagent inotify-tools wlogout neovide hypremoji swaylock fastfetch python-pywal thunar otf-font-awesome nerd-fonts
else
    paru -Sy --noconfirm alacritty swww cava waybar rofi firefox swaync torbrowser-launcher hyprpolkitagent inotify-tools wlogout neovide hypremoji swaylock fastfetch python-pywal thunar otf-font-awesome nerd-fonts
fi
sudo rm -rf /etc/wlogout
sudo mkdir /etc/wlogout
sudo cp -rv config/wlogout/* /etc/wlogout/
clear
echo "in order for theme switching to work properly, sudo needs to NOT ask for passwords for users in group wheel, wanna modify sudo to stop asking for a password?"
echo "respond in only yes or no"
read ok
if [[ "$ok" == "yes" ]]; then
	sudo mkdir /etc/sudoers.d
	cat <<EOF2 | sudo tee /etc/sudoers.d/myOverrides
%wheel ALL=(ALL:ALL) NOPASSWD: ALL
EOF2
fi
clear
echo ok DONE.
echo "last thing uhh do you want to sign out of hyprland so that the changes wouldve applied"
echo "respond with only yes or no"
read ok
if [[ "$ok" == "yes" ]]; then
	sudo killall Hyprland
fi

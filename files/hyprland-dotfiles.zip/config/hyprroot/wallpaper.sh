#!/bin/bash

# Your Hyprland root dir
HYPRDIR="$hyprrootdir"
THEME_DIR="$HYPRDIR/themes"
THUMB_DIR="$HOME/.cache/hyprthumbs"
THUMB_DIR_EXISTS=true

# Make thumbnails folder
if ! [ -d "$THUMB_DIR" ]; then
    notify-send "WARNING" "There isn't a wallpaper cache folder. It will now be created." -i dialog-warning
    mkdir -p "$THUMB_DIR"
    THUMB_DIR_EXISTS=false
fi

# Generate list of themes with thumbnails
THEMES=()
for file in "$THEME_DIR"/*; do
    [ -e "$file" ] || continue

    name=$(basename "$file")
    name="${name%.*}"  # strip extension

    thumb="$THUMB_DIR/$name.png"
    # Generate thumbnail if it doesn't exist
    if ! [ -f "$thumb" ]; then
        convert "$file" -resize 150x150 "$thumb"
        notify-send "Created thumbnail for:" "$name" -i dialog-information
    fi

    THEMES+=("$name" "$thumb")
done
if [[ "$THUMB_DIR_EXISTS" == "false" ]]; then
    if ! [ -d "$HOME/.cache/wal" ]; then
        notify-send "okay ig...?" "Created cache folder successfully, but color schemes aren't made. Wallpaper switching will generate new color schemes, which will take time." -i dialog-warning
    else
        notify-send "okay" "Created cache folder successfully." -i dialog-information
    fi
fi

# Launch YAD list with images on top
SELECTED_THEME=$(yad --title="Select Wallpaper" \
    --list \
    --width=600 --height=400 \
    --column="Wallpaper Name" --column="Preview:IMG" \
    --image-on-top \
    "${THEMES[@]}" \
    --button=OK:0 --button=Cancel:1)

# Check if user canceled
if [ $? -eq 0 ] && [ -n "$SELECTED_THEME" ]; then
    # YAD returns "ThemeName|ThumbnailPath"
    THEME_NAME=$(echo "$SELECTED_THEME" | cut -d'|' -f1)

    # Apply the theme (replace with your actual apply script)
    "$hyprrootdir/wallselect.sh" "$THEME_NAME"

    echo "Applied theme: $THEME_NAME"
else
    echo "No theme selected."
fi

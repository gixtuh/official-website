#!/bin/bash

# Your Hyprland root dir
HYPRDIR="$hyprrootdir"
THEME_DIR="$HYPRDIR/themes"
THUMB_DIR="$HOME/.cache/hyprthumbs"

# Make thumbnails folder
mkdir -p "$THUMB_DIR"

# Generate list of themes with thumbnails
THEMES=()
for file in "$THEME_DIR"/*; do
    [ -e "$file" ] || continue

    name=$(basename "$file")
    name="${name%.*}"  # strip extension

    thumb="$THUMB_DIR/$name.png"
    # Generate thumbnail if it doesn't exist
    [ -f "$thumb" ] || convert "$file" -resize 150x150 "$thumb"

    THEMES+=("$name" "$thumb")
done

# Launch YAD list with images on top
SELECTED_THEME=$(yad --title="Select Wallpaper" \
    --list \
    --width=600 --height=400 \
    --column="Wallpaper Name" --column="Preview:IMG" \
    --image-on-top \
    "${THEMES[@]}" \
    --button=OK:0 --button=Cancel:1)

# Check if user canceled
if [ $? -eq 0 ] && [ -n "$SELECTED_THEME" ]; then
    # YAD returns "ThemeName|ThumbnailPath"
    THEME_NAME=$(echo "$SELECTED_THEME" | cut -d'|' -f1)

    # Apply the theme (replace with your actual apply script)
    "$hyprrootdir/wallselect.sh" "$THEME_NAME"

    echo "Applied theme: $THEME_NAME"
else
    echo "No theme selected."
fi

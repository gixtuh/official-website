while true; do
    sleep 0.1
    sudo -E -u $USER cava &
    PID=$!
    inotifywait -qe modify ~/.config/cava/config
    kill $PID
done

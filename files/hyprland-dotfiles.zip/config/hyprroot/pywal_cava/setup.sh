#!/bin/bash

# Copy script to /usr/bin
chmod +x wal_cava.py
sudo cp wal_cava.py /usr/bin/wal_cava
# gixtuh's yet 2nd hyprland dotfiles
## made to be better than the previous ones

all credits go to:
- Zilero232/arch-install-kit for the waybar config (that i modified)
- rofi arthur for the rofi config that i ALSO modified
- and wallpapers if any of them are copyrighted

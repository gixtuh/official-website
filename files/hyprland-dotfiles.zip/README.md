# gixtuh's yet 2nd hyprland dotfiles
## made to be better than the previous ones

all credits go to:
- Zilero232/arch-install-kit for the waybar config (that i modified)
- rofi arthur for the rofi config that i ALSO modified
- and wallpapers if any of them are copyrighted

issues that I found out:
- why isnt my rofi and wlogout changing themes?
	- because your sudo keeps asking the background processes for your password and the background processes are NOT giving the password, so sudo fails because no password was provided. The only solution to this is to create an /etc/sudoers.d/yourName file and enter "%wheel ALL=(ALL:ALL) NOPASSWD: ALL in it, for some reason modifying visudo doesnt work (for me and my vm)
- why is the last widget on the center in waybar cut off
	- it's the temperature widget, and it looks cut off on your vm because your vm cant access your cpu's temperatures, so your kernel removes the cpu temperatures completely, making that widget not work
